
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const STORE='presencaIFBA_full_demo_v1';
const DEFAULTS={
 modalities:['Integrado','Subsequente','Superior','Pós-graduação'],
 courses:[
  'Técnico em Eletromecânica','Técnico em Eletrônica','Técnico em Informática','Técnico em Meio Ambiente',
  'Técnico em Edificações','Técnico em Segurança do Trabalho',
  'Engenharia Ambiental','Engenharia Civil','Engenharia Elétrica','Engenharia Mecânica',
  'Licenciatura em Química','Sistemas de Informação',
  'Especialização Lato Sensu em Desenvolvimento de Sistemas Web'
 ],
 years:['1º ano','2º ano','3º ano','4º ano','1º semestre','2º semestre','3º semestre','4º semestre','5º semestre','6º semestre','7º semestre','8º semestre','9º semestre','10º semestre'],
 classes:['A','B','C','D'],
 locations:[
  {id:'loc-aud',name:'Auditório',lat:-14.841642,lng:-40.877270,radius:10},
  {id:'loc-marta',name:'Rua Marta Vasconcelos, 125 — Centro',lat:-14.850005,lng:-40.844120,radius:10},
  {id:'loc-3',name:'Localidade 3',lat:-14.853657,lng:-40.819272,radius:10}
 ]
};
let db=loadDB(),editingId=null,currentResponseEvent=null,questionSeq=0,uploadedBanner='',locationDrafts=[];
function loadDB(){
 try{
  const saved=JSON.parse(localStorage.getItem(STORE));
  if(!saved)return {events:[],settings:JSON.parse(JSON.stringify(DEFAULTS)),responses:{}};
  saved.settings=saved.settings||{};
  // Atualiza a lista padrão sem apagar configurações personalizadas já salvas no navegador.
  for(const key of ['modalities','courses','years','classes']){
   const current=Array.isArray(saved.settings[key])?saved.settings[key]:[];
   saved.settings[key]=[...new Set([...current,...DEFAULTS[key]])];
  }
  if(!Array.isArray(saved.settings.locations))saved.settings.locations=JSON.parse(JSON.stringify(DEFAULTS.locations));
  if(!Array.isArray(saved.events))saved.events=[];
  if(!saved.responses)saved.responses={};
  return saved;
 }catch(e){return {events:[],settings:JSON.parse(JSON.stringify(DEFAULTS)),responses:{}}}
}
function persist(){localStorage.setItem(STORE,JSON.stringify(db))}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function toast(m){let t=$('#toast');t.textContent=m;t.classList.remove('hidden');clearTimeout(window._toastTimer);window._toastTimer=setTimeout(()=>t.classList.add('hidden'),3200)}
function showView(id){['dashboardView','builderView','settingsView','responsesView'].forEach(x=>$('#'+x).classList.toggle('hidden',x!==id))}
function startApp(){ $('#loginScreen').classList.add('hidden');$('#appHeader').classList.remove('hidden');$('#appMain').classList.remove('hidden');showView('dashboardView');drawEvents()}
function showLoginError(message){const el=$('#loginError');if(el){el.textContent=message;el.classList.remove('hidden')}else toast(message)}
function clearLoginError(){const el=$('#loginError');if(el){el.textContent='';el.classList.add('hidden')}}
async function verifyAdminSession(session){
 if(!session?.user) return false;
 const {data,error}=await window.supabaseClient.rpc('is_admin');
 if(error) throw error;
 if(data!==true) throw new Error('Esta conta não possui autorização de administrador no Presença IFBA.');
 return true;
}
async function restoreAdminSession(){
 if(!window.supabaseClient)return;
 try{const {data:{session}}=await window.supabaseClient.auth.getSession();if(session&&await verifyAdminSession(session))startApp();}
 catch(err){await window.supabaseClient.auth.signOut();showLoginError(err.message||'Não foi possível validar o acesso administrativo.');}
}
$('#loginForm').addEventListener('submit',async e=>{
 e.preventDefault();clearLoginError();
 if(!window.supabaseClient){showLoginError('A integração ainda não foi configurada. Abra config.js e informe a chave pública (publishable) do Supabase.');return}
 const email=$('#adminEmail').value.trim(),password=$('#adminPassword').value;
 if(!email||!password){showLoginError('Informe e-mail e senha para continuar.');return}
 const btn=$('#loginForm button[type="submit"]');if(btn){btn.disabled=true;btn.textContent='Entrando…'}
 try{
  const {data,error}=await window.supabaseClient.auth.signInWithPassword({email,password});
  if(error)throw error;
  await verifyAdminSession(data.session);
  startApp();$('#adminPassword').value='';toast('Login realizado com sucesso.');
 }catch(err){if(window.supabaseClient)await window.supabaseClient.auth.signOut();showLoginError(err.message==='Invalid login credentials'?'E-mail ou senha incorretos.':(err.message||'Não foi possível entrar.'));}
 finally{if(btn){btn.disabled=false;btn.textContent='Entrar'}}
});
$('#togglePassword').onclick=()=>{let p=$('#adminPassword');p.type=p.type==='password'?'text':'password';$('#togglePassword').textContent=p.type==='password'?'Mostrar senha':'Ocultar senha'};
$('#logoutBtn').onclick=async()=>{if(window.supabaseClient)await window.supabaseClient.auth.signOut();$('#appMain').classList.add('hidden');$('#appHeader').classList.add('hidden');$('#loginScreen').classList.remove('hidden');$('#adminPassword').value='';clearLoginError()};
if(window.supabaseClient){window.supabaseClient.auth.onAuthStateChange(async(_event,session)=>{if(!session){$('#appMain').classList.add('hidden');$('#appHeader').classList.add('hidden');if(!location.hash.includes('presenca='))$('#loginScreen').classList.remove('hidden')}});restoreAdminSession();}
$('#newEvent,#newEvent2').forEach?.(()=>{}); // no-op compatibility
function openBuilder(id=null){editingId=id;locationDrafts=[];resetBuilder();if(id){let e=db.events.find(x=>x.id===id);if(!e)return;$('#builderTitle').textContent='Editar evento';$('#eventTitle').value=e.title;$('#eventDescription').value=e.description||'';$('#eventStart').value=e.start||'';$('#eventEnd').value=e.end||'';$('#eventCode').value=e.code||'';$('#eventActive').checked=e.active!==false;$('#keepDefaults').checked=e.keepDefaults!==false;$('#gpsOn').checked=!!e.gps;uploadedBanner=e.banner||'';if(uploadedBanner)$('#bannerPreview').innerHTML=`<img src="${uploadedBanner}" alt="Banner">`;$('#bannerName').textContent=uploadedBanner?'Banner armazenado':'Nenhum arquivo selecionado';selectedFields=e.fields||Object.keys(fieldLabels);locations=JSON.parse(JSON.stringify(e.locations||db.settings.locations));(e.questions||[]).forEach(q=>addQuestion(q));}else{locations=JSON.parse(JSON.stringify(db.settings.locations));selectedFields=Object.keys(fieldLabels)}renderLocations();renderFieldConfig();$('#gpsSettings').classList.toggle('hidden',!$('#gpsOn').checked);$('#generatedResult').classList.add('hidden');showView('builderView');switchBuilderTab('config');updateSummary()}
function resetBuilder(){['eventTitle','eventDescription','eventStart','eventEnd','eventCode'].forEach(id=>$('#'+id).value='');$('#eventActive').checked=true;$('#keepDefaults').checked=true;$('#gpsOn').checked=false;$('#questions').innerHTML='';$('#bannerFile').value='';$('#bannerName').textContent='Nenhum arquivo selecionado';$('#bannerPreview').innerHTML='';uploadedBanner='';$('#generatedResult').classList.add('hidden')}
const fieldLabels={name:'Nome completo',matricula:'Matrícula',modality:'Modalidade',course:'Curso',year:'Ano/semestre',class:'Turma'};
let selectedFields=Object.keys(fieldLabels),locations=JSON.parse(JSON.stringify(DEFAULTS.locations));
function renderFieldConfig(){$('#studentFieldConfig').innerHTML=Object.entries(fieldLabels).map(([k,v])=>`<label class="switchrow"><span><strong>${v}</strong><small>Campo de identificação</small></span><input class="switch fieldToggle" type="checkbox" data-field="${k}" ${selectedFields.includes(k)?'checked':''}></label>`).join('');$$('.fieldToggle').forEach(x=>x.onchange=()=>{selectedFields=$$('.fieldToggle:checked').map(y=>y.dataset.field);updateSummary()})}
function locationCard(l,i,kind){let title=kind==='draft'?'Nova localidade':'Editar localidade';return `<div class="location" data-kind="${kind}" data-index="${i}"><div class="lochead"><strong>${kind==='draft'?'Adicionar localização':esc(l.name||title)}</strong>${kind==='saved'?`<button class="btn ghost" type="button" data-action="remove">Remover</button>`:''}</div><div class="locgrid"><div class="field"><label>Nome da localidade</label><input data-field="name" value="${esc(l.name||'')}" placeholder="Ex.: Auditório"></div><div class="field"><label>Raio permitido</label><select data-field="radius">${[10,20,30,40,50,100,200,500,1000,'Livre'].map(r=>`<option value="${r}" ${String(l.radius??10)===String(r)?'selected':''}>${r==='Livre'?'Livre':r+' m'}</option>`).join('')}</select></div><div class="field"><label>Latitude</label><input data-field="lat" type="number" step="any" value="${esc(l.lat??'')}" placeholder="Ex.: -14.841642"></div><div class="field"><label>Longitude</label><input data-field="lng" type="number" step="any" value="${esc(l.lng??'')}" placeholder="Ex.: -40.877270"></div></div><div class="toolbar"><button class="btn secondary small" type="button" data-action="save">Salvar localização</button>${kind==='draft'?'<span class="sub" style="margin:0">Preencha os dados e salve para incluir no evento.</span>':''}</div></div>`}
function renderLocations(){$('#locations').innerHTML=locations.map((l,i)=>locationCard(l,i,'saved')).join('')+locationDrafts.map((l,i)=>locationCard(l,i,'draft')).join('')}
$('#locations').addEventListener('click',ev=>{let btn=ev.target.closest('button[data-action]');if(!btn)return;let card=btn.closest('.location'),kind=card.dataset.kind,i=Number(card.dataset.index),action=btn.dataset.action;if(action==='remove'){if(confirm('Remover esta localidade do evento?')){locations.splice(i,1);renderLocations();updateSummary()}return}if(action==='save'){let read=k=>card.querySelector(`[data-field="${k}"]`).value.trim(),name=read('name'),lat=Number(read('lat')),lng=Number(read('lng')),radius=read('radius');if(!name){toast('Informe o nome da localidade.');return}if(!read('lat')||!read('lng')||!Number.isFinite(lat)||!Number.isFinite(lng)||lat < -90||lat > 90||lng < -180||lng > 180){toast('Informe uma latitude e longitude válidas.');return}let item={id:kind==='draft'?'loc-'+Date.now():locations[i].id,name,lat,lng,radius};if(kind==='draft'){locations.push(item);locationDrafts.splice(i,1);toast('Localização adicionada ao evento.')}else{locations[i]=item;toast('Localização atualizada.')}renderLocations();updateSummary()}});
$('#addLocation').onclick=()=>{locationDrafts.push({name:'',lat:'',lng:'',radius:10});renderLocations();$('#locations .location[data-kind="draft"]:last-of-type input')?.focus()};
$('#gpsOn').onchange=()=>{$('#gpsSettings').classList.toggle('hidden',!$('#gpsOn').checked);updateSummary()};
$('#keepDefaults').onchange=()=>{if($('#keepDefaults').checked){selectedFields=Object.keys(fieldLabels);renderFieldConfig()}updateSummary()};
$('#bannerFile').onchange=e=>{let f=e.target.files[0];if(!f)return;if(f.size>1800000){toast('A imagem deve ter até 1,8 MB para armazenamento local.');e.target.value='';return}let r=new FileReader();r.onload=()=>{uploadedBanner=r.result;$('#bannerName').textContent=f.name;$('#bannerPreview').innerHTML=`<img src="${uploadedBanner}" alt="Prévia do banner">`};r.readAsDataURL(f)};
function addQuestion(q=null){let id=++questionSeq;let el=document.createElement('div');el.className='question';el.dataset.qid=id;el.innerHTML=`<div class="qtop"><strong>Pergunta adicional</strong><div class="toolbar"><button class="btn secondary small" type="button" onclick="moveQuestion(this,-1)">↑</button><button class="btn secondary small" type="button" onclick="moveQuestion(this,1)">↓</button><button class="btn ghost" type="button" onclick="this.closest('.question').remove()">Excluir</button></div></div><div class="field"><label>Enunciado</label><input class="qprompt" placeholder="Digite a pergunta"></div><div class="grid2"><div class="field"><label>Tipo de resposta</label><select class="qtype"><option value="short">Texto curto</option><option value="long">Texto longo</option><option value="choice">Múltipla escolha</option></select></div><div class="field"><label>Obrigatoriedade</label><select class="qrequired"><option value="true">Obrigatória</option><option value="false">Opcional</option></select></div></div><div class="options hidden"><label>Alternativas</label><div class="optionList"></div><button class="btn secondary small addOption" type="button">＋ Adicionar alternativa</button></div>`;
$('#questions').appendChild(el);let sel=el.querySelector('.qtype');sel.onchange=()=>el.querySelector('.options').classList.toggle('hidden',sel.value!=='choice');el.querySelector('.addOption').onclick=()=>addOption(el);if(q){el.querySelector('.qprompt').value=q.prompt;sel.value=q.type;el.querySelector('.qrequired').value=String(q.required);if(q.type==='choice'){el.querySelector('.options').classList.remove('hidden');q.options.forEach(o=>addOption(el,o))}}updateQuestionCount();return el}
function addOption(el,value=''){let row=document.createElement('div');row.className='choice';row.innerHTML=`<span>•</span><input placeholder="Alternativa" value="${esc(value)}"><button type="button" class="btn ghost">Remover</button>`;row.querySelector('button').onclick=()=>row.remove();el.querySelector('.optionList').appendChild(row)}
window.moveQuestion=(btn,dir)=>{let el=btn.closest('.question'),sib=dir<0?el.previousElementSibling:el.nextElementSibling;if(sib){if(dir<0)el.parentNode.insertBefore(el,sib);else el.parentNode.insertBefore(sib,el)}};
$('#addQuestion').onclick=()=>addQuestion();
function updateQuestionCount(){let n=$$('#questions .question').length;$('#questionCount').textContent=n?`${n} pergunta(s) adicional(is)`:'Nenhuma pergunta adicionada'}
function collectQuestions(){return $$('#questions .question').map(q=>({prompt:q.querySelector('.qprompt').value.trim(),type:q.querySelector('.qtype').value,required:q.querySelector('.qrequired').value==='true',options:[...q.querySelectorAll('.optionList input')].map(x=>x.value.trim()).filter(Boolean)})).filter(q=>q.prompt)}
function updateSummary(){$('#summaryTitle').textContent=$('#eventTitle').value||'PRESENÇA IFBA';$('#summaryDescription').textContent=$('#eventDescription').value||'Formulário de presença do evento';$('#summaryFields').textContent='Campos: '+selectedFields.map(k=>fieldLabels[k]).join(', ');$('#summaryGps').textContent=$('#gpsOn').checked?'GPS obrigatório · '+locations.length+' localidade(s)':'GPS desativado'}
['eventTitle','eventDescription'].forEach(id=>$('#'+id).addEventListener('input',updateSummary));
function collectEvent(){return {id:editingId||'evt-'+Date.now(),title:$('#eventTitle').value.trim(),description:$('#eventDescription').value.trim(),start:$('#eventStart').value,end:$('#eventEnd').value,code:$('#eventCode').value.trim(),active:$('#eventActive').checked,fields:selectedFields,keepDefaults:$('#keepDefaults').checked,questions:collectQuestions(),gps:$('#gpsOn').checked,locations:JSON.parse(JSON.stringify(locations)),banner:uploadedBanner,createdAt:editingId?(db.events.find(e=>e.id===editingId)?.createdAt||new Date().toISOString()):new Date().toISOString()}}
function validateEvent(e){if(!e.title){toast('Informe o nome do evento.');return false}if(!e.start||!e.end){toast('Informe a data e a hora de abertura e encerramento.');return false}if(new Date(e.end)<=new Date(e.start)){toast('O encerramento deve ser posterior à abertura.');return false}if(!e.fields.length&&!e.questions.length){toast('Selecione ao menos um campo ou pergunta.');return false}if(e.gps&&(locationDrafts.length||!e.locations.length||e.locations.some(l=>!Number.isFinite(Number(l.lat))||!Number.isFinite(Number(l.lng))))){toast('Salve todas as localidades e revise as coordenadas GPS.');return false}return true}
function saveEvent(generate=false){let e=collectEvent();if(!validateEvent(e))return;let i=db.events.findIndex(x=>x.id===e.id);if(i>=0)db.events[i]=e;else db.events.unshift(e);persist();drawEvents();if(generate){let url=location.href.split('#')[0]+'#presenca='+encodeURIComponent(e.id);e.url=url;persist();$('#generatedResult').classList.remove('hidden');$('#studentLink').href=url;$('#studentLink').textContent=url;$('#qrBox').innerHTML='';if(window.QRCode)new QRCode($('#qrBox'),{text:url,width:160,height:160});else $('#qrBox').textContent='Biblioteca de QR Code indisponível.';toast('Evento salvo e formulário gerado.')}else toast('Evento salvo neste navegador.')}
$('#saveEvent').onclick=()=>saveEvent(false);$('#generateForm').onclick=()=>saveEvent(true);
$('#copyLink').onclick=async()=>{try{await navigator.clipboard.writeText($('#studentLink').href);toast('Link copiado.')}catch(e){toast('Copie o endereço exibido no campo do link.')}};
$('#showQr').onclick=()=>$('#qrBox').classList.toggle('hidden');
function drawEvents(){let q=($('#eventSearch')?.value||'').toLowerCase();let items=db.events.filter(e=>e.title.toLowerCase().includes(q));$('#eventCount').textContent=`${db.events.length} evento(s) cadastrado(s)`;$('#eventList').innerHTML=items.length?items.map(e=>`<div class="event-row"><div class="rowhead"><div><strong>${esc(e.title)}</strong><div class="sub" style="margin:4px 0 0">${e.start?new Date(e.start).toLocaleString('pt-BR'):'Sem data'} · <span class="pill">${e.active?'Ativo':'Inativo'}</span> · ${(db.responses[e.id]||[]).length} participante(s)</div></div><div class="toolbar"><button class="btn secondary small" onclick="editEvent('${e.id}')">Editar</button><button class="btn secondary small" onclick="viewResponses('${e.id}')">Respostas</button><button class="btn secondary small" onclick="toggleEvent('${e.id}')">${e.active?'Desativar':'Ativar'}</button><button class="btn secondary small" onclick="copyEventLink('${e.id}')">Copiar link</button><button class="btn ghost" onclick="deleteEvent('${e.id}')">Excluir</button></div></div></div>`).join(''):'<div class="empty">Nenhum evento encontrado. Clique em “Cadastrar evento” para começar.</div>'}
window.editEvent=id=>openBuilder(id);
window.toggleEvent=id=>{let e=db.events.find(x=>x.id===id);e.active=!e.active;persist();drawEvents();toast('Situação do evento atualizada.')};
window.deleteEvent=id=>{if(confirm('Excluir este evento e suas respostas armazenadas neste navegador?')){db.events=db.events.filter(x=>x.id!==id);delete db.responses[id];persist();drawEvents();toast('Evento excluído.')}};
window.copyEventLink=async id=>{let url=location.href.split('#')[0]+'#presenca='+encodeURIComponent(id);try{await navigator.clipboard.writeText(url);toast('Link copiado.')}catch(e){prompt('Copie o link do formulário:',url)}};
$('#eventSearch').oninput=drawEvents;
$('#newEvent').onclick=()=>openBuilder();$('#newEvent2').onclick=()=>openBuilder();$('#goEvents').onclick=()=>$('#eventListCard').scrollIntoView({behavior:'smooth'});$('#goSettings').onclick=()=>{showView('settingsView');renderSettings()};
$('#backDashboard,#settingsBack,#responsesBack').forEach?.(()=>{});
['backDashboard','settingsBack','responsesBack'].forEach(id=>$('#'+id).onclick=()=>{showView('dashboardView');drawEvents()});
$$('.tab').forEach(b=>b.onclick=()=>switchBuilderTab(b.dataset.tab));
function switchBuilderTab(tab){$$('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));$('#configTab').classList.toggle('hidden',tab!=='config');$('#studentPreviewTab').classList.toggle('hidden',tab!=='studentPreview');if(tab==='studentPreview')renderBuilderPreview()}
function renderBuilderPreview(){let e=collectEvent();$('#previewStudent').innerHTML=`<h2>${esc(e.title||'Nome do evento')}</h2><p>${esc(e.description)}</p>${e.banner?`<img class="student-banner" src="${e.banner}">`:''}<p class="muted">Campos: ${e.fields.map(x=>fieldLabels[x]).join(', ')}</p>${e.questions.map(q=>`<p><strong>${esc(q.prompt)}</strong> · ${q.type}</p>`).join('')}`}
function renderSettings(){renderSimpleList('modalities','modalityList','modalidade');renderSimpleList('courses','courseList','curso');renderSimpleList('years','yearList','ano/semestre');renderSimpleList('classes','classList','turma');$('#settingsLocations').innerHTML=db.settings.locations.map((l,i)=>`<div class="location"><div class="rowhead"><strong>${esc(l.name)}</strong><button class="btn ghost" onclick="removeSettingLocation(${i})">Excluir</button></div><p class="coords">${l.lat}, ${l.lng} · Raio ${l.radius==='Livre'?'livre':l.radius+' m'}</p></div>`).join('')}
function renderSimpleList(key,target,label){$('#'+target).innerHTML=db.settings[key].map((v,i)=>`<div class="switchrow"><span>${esc(v)}</span><button class="btn ghost" onclick="removeSetting('${key}',${i})">Excluir</button></div>`).join('')||'<p class="sub">Nenhum item cadastrado.</p>'}
window.removeSetting=(key,i)=>{if(confirm('Excluir este item?')){db.settings[key].splice(i,1);persist();renderSettings()}};
function addSetting(key,input){let v=$('#'+input).value.trim();if(!v)return;db.settings[key].push(v);$('#'+input).value='';persist();renderSettings()}
$('#addModality').onclick=()=>addSetting('modalities','newModality');$('#addCourse').onclick=()=>addSetting('courses','newCourse');$('#addYear').onclick=()=>addSetting('years','newYear');$('#addClass').onclick=()=>addSetting('classes','newClass');
window.removeSettingLocation=i=>{if(confirm('Excluir esta localidade das configurações?')){db.settings.locations.splice(i,1);persist();renderSettings()}};
$('#addSettingsLocation').onclick=()=>{let name=prompt('Nome da localidade:');if(!name)return;let lat=prompt('Latitude:');let lng=prompt('Longitude:');if(!Number.isFinite(Number(lat))||!Number.isFinite(Number(lng))){toast('Coordenadas inválidas.');return}db.settings.locations.push({id:'loc-'+Date.now(),name,lat:Number(lat),lng:Number(lng),radius:10});persist();renderSettings()};
function viewResponses(id){currentResponseEvent=id;let e=db.events.find(x=>x.id===id);showView('responsesView');$('#responsesTitle').textContent='Respostas — '+e.title;let rows=db.responses[id]||[];$('#responseCount').textContent=rows.length+' registro(s)';$('#responsesTable').innerHTML=rows.length?`<table><thead><tr><th>Data/hora</th><th>Nome</th><th>Matrícula</th><th>Demais respostas</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${new Date(r.createdAt).toLocaleString('pt-BR')}</td><td>${esc(r.name||'—')}</td><td>${esc(r.matricula||'—')}</td><td>${Object.entries(r.answers||{}).map(([k,v])=>`<strong>${esc(k)}:</strong> ${esc(v)}`).join('<br>')}</td></tr>`).join('')}</tbody></table>`:'<div class="empty">Ainda não há respostas para este evento.</div>'}
window.viewResponses=viewResponses;
$('#exportCsv').onclick=()=>{let rows=db.responses[currentResponseEvent]||[];if(!rows.length){toast('Não há respostas para exportar.');return}let headers=['Data/hora','Nome','Matrícula','Respostas'];let csv=[headers,...rows.map(r=>[new Date(r.createdAt).toLocaleString('pt-BR'),r.name||'',r.matricula||'',JSON.stringify(r.answers||{})])].map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(';')).join('\\n');let a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\\ufeff'+csv],{type:'text/csv;charset=utf-8'}));a.download='presencas-evento.csv';a.click();URL.revokeObjectURL(a.href)};
function distanceM(a,b,c,d){let R=6371000,rad=x=>x*Math.PI/180,dl=rad(c-a),dn=rad(d-b);let x=Math.sin(dl/2)**2+Math.cos(rad(a))*Math.cos(rad(c))*Math.sin(dn/2)**2;return 2*R*Math.atan2(Math.sqrt(x),Math.sqrt(1-x))}
function showLocationBlock(message){$('#attendanceForm').classList.add('hidden');$('#publicClosed').textContent=message;$('#publicClosed').classList.remove('hidden');$('#submitAttendance').disabled=true}
function checkPublicLocation(e,onAllowed){
 if(!e.gps){onAllowed();return}
 if(!navigator.geolocation){showLocationBlock('Não foi possível verificar sua localização. Ative a localização do aparelho e tente novamente.');return}
 $('#attendanceForm').classList.add('hidden');$('#publicClosed').textContent='Verificando sua localização…';$('#publicClosed').classList.remove('hidden');
 navigator.geolocation.getCurrentPosition(pos=>{
  const {latitude:lat,longitude:lng,accuracy}=pos.coords;
  if(accuracy>50){showLocationBlock('Não foi possível confirmar sua localização com precisão suficiente. Ative o GPS e tente novamente em um local com melhor sinal.');return}
  const allowed=(e.locations||[]).some(l=>l.radius==='Livre'||distanceM(lat,lng,Number(l.lat),Number(l.lng))<=Number(l.radius));
  if(!allowed){showLocationBlock('Infelizmente você está fora da localização adequada para a execução desse formulário. Por favor, entre em contato com a organização.');return}
  $('#publicClosed').classList.add('hidden');$('#attendanceForm').classList.remove('hidden');$('#submitAttendance').disabled=false;onAllowed({lat,lng,accuracy});
 },()=>showLocationBlock('Não foi possível obter sua localização. Autorize o acesso ao GPS e atualize a página.'),{enableHighAccuracy:true,timeout:20000,maximumAge:0});
}
function openPublicForm(id){let e=db.events.find(x=>x.id===id);$('#appHeader').classList.add('hidden');$('#appMain').classList.add('hidden');$('#loginScreen').classList.add('hidden');$('#publicForm').classList.remove('hidden');if(!e){$('#publicTitle').textContent='Formulário não encontrado';$('#publicClosed').textContent='O link não corresponde a um evento cadastrado neste navegador.';$('#publicClosed').classList.remove('hidden');$('#attendanceForm').classList.add('hidden');return}
$('#publicTitle').textContent=e.title;$('#publicDescription').textContent=e.description||'';$('#publicBanner').classList.toggle('hidden',!e.banner);if(e.banner)$('#publicBanner').src=e.banner;$('#publicClosed').classList.add('hidden');$('#attendanceForm').classList.add('hidden');
let now=Date.now(),start=e.start?new Date(e.start).getTime():0,end=e.end?new Date(e.end).getTime():Infinity,closed=!e.active||now<start||now>end;
if(closed){$('#publicClosed').textContent=!e.active?'Este evento está desativado.':now<start?'O formulário ainda não está aberto.':'O período de confirmação foi encerrado.';$('#publicClosed').classList.remove('hidden');$('#submitAttendance').disabled=true;return}
$('#codeField').classList.toggle('hidden',!e.code);$('#publicGps').classList.toggle('hidden',!e.gps);
let fields='';(e.fields||[]).forEach(k=>{let label=fieldLabels[k];if(!label)return;if(k==='modality')fields+=`<div class="field"><label>${label} *</label><select name="${k}" required><option value="">Selecione</option>${db.settings.modalities.map(v=>`<option>${esc(v)}</option>`).join('')}</select></div>`;
else if(k==='course')fields+=`<div class="field"><label>${label} *</label><select name="${k}" required><option value="">Selecione</option>${db.settings.courses.map(v=>`<option>${esc(v)}</option>`).join('')}</select></div>`;
else if(k==='year')fields+=`<div class="field"><label>${label} *</label><select name="${k}" required><option value="">Selecione</option>${db.settings.years.map(v=>`<option>${esc(v)}</option>`).join('')}</select></div>`;
else if(k==='class')fields+=`<div class="field"><label>${label} *</label><select name="${k}" required><option value="">Selecione</option>${db.settings.classes.map(v=>`<option>${esc(v)}</option>`).join('')}</select></div>`;
else fields+=`<div class="field"><label>${label} *</label><input name="${k}" ${k==='matricula'?'inputmode="numeric"':''} required></div>`});
(e.questions||[]).forEach((q,i)=>{let req=q.required?'required':'';fields+=`<div class="field"><label>${esc(q.prompt)} ${q.required?'*':''}</label>${q.type==='long'?`<textarea name="custom_${i}" rows="3" ${req}></textarea>`:q.type==='choice'?`<select name="custom_${i}" ${req}><option value="">Selecione</option>${q.options.map(o=>`<option>${esc(o)}</option>`).join('')}</select>`:`<input name="custom_${i}" ${req}>`}</div>`});
$('#publicFields').innerHTML=fields;$('#attendanceForm').onsubmit=ev=>submitAttendance(ev,e);
checkPublicLocation(e,()=>{});
}
function submitAttendance(ev,e){ev.preventDefault();if(e.code&&$('#publicCode').value!==e.code){toast('Código de acesso incorreto.');return}
let form=$('#attendanceForm'),data=new FormData(form),answers={},name=data.get('name')||'',matricula=data.get('matricula')||'';for(let [k,v] of data.entries())if(k!=='name'&&k!=='matricula')answers[k]=v;
let existing=db.responses[e.id]||[];if(matricula&&existing.some(r=>String(r.matricula).trim()===String(matricula).trim())){toast('Já existe uma presença registrada para esta matrícula neste evento.');return}
let save=(coords=null)=>{let record={name,matricula,answers,coords,createdAt:new Date().toISOString()};existing.push(record);db.responses[e.id]=existing;persist();$('#attendanceForm').classList.add('hidden');$('#publicSuccess').textContent='Presença registrada com sucesso neste navegador. Guarde esta confirmação.';$('#publicSuccess').classList.remove('hidden')};
if(e.gps){if(!navigator.geolocation){showLocationBlock('Não foi possível verificar sua localização. Ative a localização do aparelho e tente novamente.');return}navigator.geolocation.getCurrentPosition(pos=>{let lat=pos.coords.latitude,lng=pos.coords.longitude,accuracy=pos.coords.accuracy,allowed=accuracy<=50&&e.locations.some(l=>l.radius==='Livre'||distanceM(lat,lng,Number(l.lat),Number(l.lng))<=Number(l.radius));if(!allowed){showLocationBlock(accuracy>50?'Não foi possível confirmar sua localização com precisão suficiente. Ative o GPS e tente novamente em um local com melhor sinal.':'Infelizmente você está fora da localização adequada para a execução desse formulário. Por favor, entre em contato com a organização.');return}save({lat,lng,accuracy})},()=>showLocationBlock('Não foi possível obter sua localização. Autorize o acesso ao GPS e atualize a página.'),{enableHighAccuracy:true,timeout:20000,maximumAge:0})}else save()}
let hash=location.hash.match(/#presenca=([^&]+)/);if(hash){openPublicForm(decodeURIComponent(hash[1]))}
renderSettings();
